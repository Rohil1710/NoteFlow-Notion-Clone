import boto3
import json
import os
from google.oauth2 import id_token
from google.auth.transport import requests

DYNAMODB_TABLE = os.environ["DYNAMODB_TABLE"]
GOOGLE_CLIENT_ID = os.environ["GOOGLE_CLIENT_ID"]

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table(DYNAMODB_TABLE)


def lambda_handler(event, context):
    email = event['queryStringParameters']['email']
    access_token = event['headers']['access_token']

    print(event)
    http_method = event["requestContext"]["http"]["method"].lower()
    invoker = None

    if http_method == "post" or http_method == "put":
        # POST and PUT use the request body to get info about the request
        body = json.loads(event["body"])
        invoker = body["invoker"]
    elif http_method == "get" or http_method == "delete":
        # GET and DELETE use query string parameters to get info about the request
        invoker = event["queryStringParameters"]["invoker"]

    try:
        # Validate the access token
        id_info = id_token.verify_oauth2_token(access_token, requests.Request(), GOOGLE_CLIENT_ID)
        if id_info['email'] != email:
            raise ValueError("Email mismatch")
    except ValueError as e:
        print(e)
        return {
            "statusCode": 401,
            "body": json.dumps({"message": "Invalid or expired access token"})
        }

    try:
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key("email").eq(email)
        )
        notes = response["Items"]
    except Exception as e:
        print(e)
        return {
            "statusCode": 500,
            "body": json.dumps({"message": "Error retrieving notes"})
        }

    return {
        "statusCode": 200,
        "body": json.dumps(notes),
        "headers": {
            "Access-Control-Allow-Origin": "https//localhost:3000",
            "Access-Control-Allow-Headers": "Content-Type,access_token",
            "Access-Control-Allow-Methods": "OPTIONS,POST,GET,DELETE"
        },
    }
